#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <unistd.h>
#include <windows.h>
int main()
{	Start:
	char key, input[5], charin[20], again[5];
	int length, output, numInput[10];
	int i=1, j, checker, num;
	{
			system("cls");
			printf("Enter 10 numbers \n");
			do
			{
				int error = 0;
				if(i == 1)
				{
					printf("Enter the %dst number :", i);
				} else if (i == 2)
				{
					printf("Enter the %dnd number :", i);
				} else if(i == 3)
				{
						printf("Enter the %drd number :", i);
				} else
				{
						printf("Enter the %dth number :", i);
				}
				scanf("%[^\n]%*c", &charin);
				length = strlen(charin);
				for(checker = 0; checker <= length; checker++)
				{
					if(isspace(charin[checker]) || isalpha(charin[checker]))
					{
						error = 1;
					}
				}
				if(length != 0 && error == 0)
				{
					++i;
					numInput[i-1] = atoi(charin);
			}
				else
				{
					printf("Invalid input!");
					printf("\nDo you want to start again? Note: Yes or No only. ");
					scanf("%s", &again);
					fflush(stdin);
				}
				
			} 
			while( i <= 10);
			for(i = 1; i <= 10; i++)
			{
				for (j = i + 1; j < 11; j++)
            	{
	 
	                if (numInput[i] > numInput[j]) 
	                {
	                    int a =  numInput[i];
	                    numInput[i] = numInput[j];
	                    numInput[j] = a;
	                }
				} 
        	}
        	 printf("The numbers arranged in ascending order are given below \n");
        	for (i = 1; i <= 10; i++)
            printf("%d\n", numInput[i]);
 			fflush(stdin);
		}
  

Initiate:{printf("\nDo you want to try again?[Y/N]:");
scanf("%s", &again);
fflush(stdin);

if(again[0]=='Y'||again[0]=='y'){
	goto Start;

}

if(again[0]=='N'||again[0]=='n'){
	printf("Thank You!");
	return 0;
}
else{
	printf("Invalid Input\n");
	goto Initiate;
 }
}
}


	

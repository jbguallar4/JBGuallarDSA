#include<iostream>
using namespace std;

int x,y,z;
int row, col;

void printArray();
void printRow();
void printCol();
void fileHandling();
void repeat();

int main(){
	int a, b;
	printArray();
	cout << "Select row number(1-10): "; 
		while(!(cin>> row)){
		cout<<"Invalid input try again: ";
		cin.clear();
		cin.sync();
		}	
		 fileHandling();
		printRow();
	cout << "\nSelect column number(1-10): "; 
		while(!(cin>> col)){
		cout<<"Invalid input try again: ";
		cin.clear();
		cin.sync();
		}	
		fileHandling();
		printCol();
		repeat();
	

}
void printCol(){
	for(x = 1; x<= 10; x++){
		for(y =1; y <= 10; y++){
			if(x == row){
				if(x == y){
					cout << "1\n";
				}
				else{
					cout << "0\n";
				}
			}
			
		}
	}
}
void printRow(){
	
	for(x = 1; x<= 10; x++){
		for(y =1; y <= 10; y++){
			if(y == row){
				if(x == y){
					cout << "1\t";
				}
				else{
					cout << "0\t";
				}
			}
			
		}
	}
}
void printArray(){
	
	int arr[10][10];
	
	for(x = 1; x <= 10; x++){
		for(y = 1; y <= 10; y++){
			if(x==y){
				z = arr[x-1][y-1] = 1;
				cout << z << "\t";
			}
			else{
			z = arr[x-1][y-1] = 0;
				cout << arr[x-1][y-1] << "\t";
			}
			if(y%10==0){
		cout << endl;
		
	}
	}
	}
		
}
void fileHandling(){
		if(cin.fail()){
		cin.clear();
		cin.ignore(100,'\n');
		system("cls");
		cout <<"Invalid Input!\n";
//		system("pause");
		}
}
void repeat(){
	cin.ignore(100,'\n');
	char yesNo;
	cout << "\nTry Again? (y/n): " ; cin >> yesNo;
	system("cls");
	if (yesNo == 'y' || yesNo == 'Y'){
		main();
	}
	else if(yesNo == 'n' || yesNo == 'N'){
		system("exit");
	}
	else{
		cout << "Invalid Choice\t Exiting...";
		system("exit");
		
	}
}

#include <iostream>
#include <cstring>

using namespace std;

int main()
{
	char str1[100], str2[100];

	cout << "Enter the first word (str1): ";
	cin.getline(str1, 100);
	cout << "Enter the second word (str2): ";
	cin.getline(str2, 100);
	strcmp(str1, str2) == 0 ? (cout << "Equal") : (strcmp(str1, str2) == 1 ? (cout << "Positive") : (cout << "Negative"));
	cout << endl;

	system("pause>0");
	return 0;
}
